# MongoDB Atlas plugin

This plugin adds completion for [Atlas](https://www.mongodb.com/docs/atlas/cli/stable/) a command line interface built specifically for 
MongoDB Atlas.

To use it, add `mongo-atlas` to the plugins array in your zshrc file:

```zsh
plugins=(... mongo-atlas)
```
